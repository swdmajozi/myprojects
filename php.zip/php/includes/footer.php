 <div class="site-footer">
        <div class="container">
        <div class="row-fluid">
            <div class="span8 offset2">
        <div class="copy-rights">
            Copyright (c) Rumman. All rights reserved. 
        </div>
        </div>
        </div>
        </div>
        <div class="site-content">
        <p class="last">Developed By: <a href="#">Md. Raqibul Hasan Rumman</a></p>
          
        </div>
</div>                  

        <!-- /container -->
<script src="js/jquery-1.9.1.js"></script> 
<script src="js/bootstrap.js"></script>
</body>