<div class="wrap-bg">
<div class="site-header">
    <div class="logo">
        <img src="img/logo.png">
        <h1><span style="text-transform: none;">QuickQuizzes</span> By RUMMAN</h1>
    </div>
</div>
<div class="container">
<div class="banner">
   <div class="carousel slide" id="myCarousel">
            <!-- Carousel items -->
            <div class="carousel-inner">
                <div class="item">
                    <img src="img/ms4d.jpg" alt="">
                    <div class="carousel-caption">
                     <!-- <h1>Exam System</h1>
                      <h2>Lorem Ipsum</h2>-->
                      <div class="social-icons" style="margin-top: 120px;">
                        <ul>
                            <li><a href="#"><i class="fw-icon-facebook icon"></i></a></li>
                            <li><a href="#"><i class="fw-icon-twitter icon"></i></a></li>
                            <li><a href="#"><i class="fw-icon-google-plus icon"></i></a></li>
                        </ul>
                    </div>
                    </div>
                </div>
                <div class="item active">
                    <img src="img/ams3.jpg" alt="">
                    <div class="carousel-caption">
                     <!-- <h1>Online Exam</h1>
                      <h2>Lorem Ipsum</h2>-->
                      <div class="social-icons" style="margin-top: 90px;">
                        <ul>
                            <li><a href="#"><i class="fw-icon-facebook icon"></i></a></li>
                            <li><a href="#"><i class="fw-icon-twitter icon"></i></a></li>
                            <li><a href="#"><i class="fw-icon-google-plus icon"></i></a></li>
                        </ul>
                    </div>
                    </div>
                </div>
                                                  
             </div>
        <!-- Carousel nav -->
        <a data-slide="prev" href="#myCarousel" class="carousel-control left"><i class="fw-icon-chevron-left"></i></a>
        <a data-slide="next" href="#myCarousel" class="carousel-control right"><i class="fw-icon-chevron-right"></i></a>
     </div>
</div>
</div>
</div>